# Copernico Theme #

**Copernico versión 3.18** es un tema para GNOME Shell que proporciona
  un aspecto visual ligeramente mas agradable al que viene por
  defecto.

Tema original de GNOME y modificado por Michael Yugcha
[@mgyugcha](https://www.twitter.com/mgyugcha), bajo los términos de la
licencia GPL v3.

### Descarga ###

Puedes descargar la última versión en
[este enlace.](https://github.com/mgyugcha/copernico-theme/archive/master.zip)

### Capturas ###

* Escritorio:

![](https://raw.githubusercontent.com/mgyugcha/copernico-theme/master/images/copernico.png)
* Aplicaciones

![](https://raw.githubusercontent.com/mgyugcha/copernico-theme/master/images/copernico-apps.png)
* Cierre de sesión

![](https://raw.githubusercontent.com/mgyugcha/copernico-theme/master/images/copernico-end-session.png)
